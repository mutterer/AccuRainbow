package accurainbow.lambda;

import processing.core.*;

/**
 * This is a processing Library to get a processing color corresponding to a
 * wavelength. 
 * Lambda to RGB math taken from
 * https://web.archive.org/web/20071011014339/http://www.efg2.com/Lab/
 * ScienceAndEngineering/Spectra.htm
 * 
 */

public class Lambda {

	PApplet myParent;

	int lambda = 0;
	int color = 0;
	double r, g, b;
	double gamma = 0.8D;
	int intensityMax = 255;
	double factor = 0.0;

	public final static String VERSION = "1.0.0";

	/**
	 * Constructor
	 * 
	 * @param theParent
	 */
	public Lambda(PApplet theParent) {
		myParent = theParent;
		welcome();
	}

	private void welcome() {
		// System.out.println("AccuRainbow started");
	}

	public String sayHello() {
		return "Hello AccuRainbow library.";
	}

	/**
	 * return the version of the Library.
	 * 
	 * @return String
	 */
	public static String version() {
		return VERSION;
	}

	/**
	 * lambda to RGB
	 * returns 32bit ARGB color from given integer wavelength
	 * follows the math from
	 * https://web.archive.org/web/20071011014339/http://www.efg2.com/Lab/
	 * 
	 * @return int
	 */
	public int getColor(int l) {

		r = 0;
		g = 0;
		b = 0;

		if ((l >= 380) && (l < 440)) {
			r = -(l - 440D) / (440D - 380D);
			g = 0;
			b = 1;
		} else if ((l >= 440) && (l < 490)) {
			r = 0;
			g = (l - 440D) / (490D - 440D);
			b = 1;
		} else if ((l >= 490D) && (l < 510D)) {
			r = 0;
			g = 1;
			b = -(l - 510D) / (510D - 490D);
		} else if ((l >= 510) && (l < 580)) {
			r = (l - 510D) / (580D - 510D);
			g = 1;
			b = 0;
		} else if ((l >= 580) && (l < 645)) {
			r = 1;
			g = -(l - 645D) / (645D - 580D);
			b = 0;
		} else if ((l >= 645) && (l < 780)) {
			r = 1;
			g = 0;
			b = 0;
		} else {
			r = 0;
			g = 0;
			b = 0;
		}
		if ((l >= 380) && (l < 420)) {
			factor = 0.3 + 0.7 * (l - 380.0) / (420.0 - 380.0);
		} else if ((l >= 420) && (l < 701)) {
			factor = 1.0;
		} else if ((l >= 701) && (l < 780)) {
			factor = 0.3D + 0.7D * (780D - l) / (780.0 - 700.0);
		} else
			factor = 0.0;

		r = adjust(r, factor);
		g = adjust(g, factor);
		b = adjust(b, factor);

		color = ((int) (0xff000000+ r * 256D * 256D + g * 256D + b)) & 0xffffffff;

		return color;
	}

	public double adjust(double c, double factor) {
		if (c == 0)
			return 0;
		else
			return Math.round(intensityMax * Math.pow(c * factor, gamma));
	}
}
